exports.recordDoubleEntry = async (
  Journal,
  description,
  debit,
  credit,
  amount,
) => {
  if (amount <= 0) throw new Error("Invalid amount");

  await Journal.create({
    date: new Date(),
    description,
    debitAccount: debit,
    creditAccount: credit,
    amount,
  });
};
