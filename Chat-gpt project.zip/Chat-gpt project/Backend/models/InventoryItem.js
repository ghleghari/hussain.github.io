const mongoose = require("mongoose");

const InventoryItemSchema = new mongoose.Schema({
  name: String,
  type: { type: String, enum: ["RAW", "FINISHED"] },
  quantity: Number,
  avgCost: Number,
});

module.exports = mongoose.model("InventoryItem", InventoryItemSchema);
