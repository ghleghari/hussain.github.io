const mongoose = require("mongoose");

const JournalEntrySchema = new mongoose.Schema({
  date: Date,
  description: String,
  debitAccount: String,
  creditAccount: String,
  amount: Number,
});

module.exports = mongoose.model("JournalEntry", JournalEntrySchema);
