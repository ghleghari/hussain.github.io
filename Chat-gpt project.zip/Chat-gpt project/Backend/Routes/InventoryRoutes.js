const router = require("express").Router();
const InventoryItem = require("../models/InventoryItem");

router.get("/", async (req, res) => {
  const items = await InventoryItem.find();
  res.json(items);
});

module.exports = router;
