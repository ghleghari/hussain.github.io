const express = require("express");
const router = express.Router();

// Login route
router.post("/login", (req, res) => {
  const { username, password } = req.body;

  if (username === "admin" && password === "123") {
    return res.json({ token: "admin-token" });
  }

  res.status(401).json({ message: "Invalid credentials" });
});

module.exports = router;
