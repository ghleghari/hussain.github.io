const router = require("express").Router();
const JournalEntry = require("../models/JournalEntry");

router.get("/trial-balance", async (req, res) => {
  const entries = await JournalEntry.find();
  res.json(entries);
});

module.exports = router;
