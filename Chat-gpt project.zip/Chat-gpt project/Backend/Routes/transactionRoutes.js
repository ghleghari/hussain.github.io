const router = require("express").Router();
const InventoryItem = require("../models/InventoryItem");
const JournalEntry = require("../models/JournalEntry");
const { recordDoubleEntry } = require("../utils/accounting");

router.post("/purchase", async (req, res) => {
  const { itemId, quantity, rate } = req.body;

  const item = await InventoryItem.findById(itemId);
  const total = quantity * rate;

  const newQty = item.quantity + quantity;
  item.avgCost = (item.quantity * item.avgCost + total) / newQty;
  item.quantity = newQty;
  await item.save();

  await recordDoubleEntry(
    JournalEntry,
    "Purchase",
    "Inventory",
    "Cash/AP",
    total,
  );
  res.json({ success: true });
});

router.post("/sale", async (req, res) => {
  const { itemId, quantity, rate } = req.body;

  const item = await InventoryItem.findById(itemId);
  const revenue = quantity * rate;
  const cogs = quantity * item.avgCost;

  item.quantity -= quantity;
  await item.save();

  await recordDoubleEntry(JournalEntry, "Sale", "Cash/AR", "Revenue", revenue);
  await recordDoubleEntry(JournalEntry, "COGS", "COGS", "Inventory", cogs);

  res.json({ success: true });
});

module.exports = router;
