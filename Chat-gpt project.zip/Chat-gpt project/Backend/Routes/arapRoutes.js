const router = require("express").Router();
const Customer = require("../models/Customer");
const Supplier = require("../models/Supplier");

router.get("/customers", async (req, res) => {
  res.json(await Customer.find());
});

router.get("/suppliers", async (req, res) => {
  res.json(await Supplier.find());
});

module.exports = router;
