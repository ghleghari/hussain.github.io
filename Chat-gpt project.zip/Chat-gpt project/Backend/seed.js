const mongoose = require("mongoose");
const InventoryItem = require("./models/InventoryItem");

mongoose.connect(
  "mongodb+srv://aghari_db_user:123@cluster0.et9hv9k.mongodb.net/",
);

const seedData = async () => {
  await InventoryItem.deleteMany();

  await InventoryItem.insertMany([
    { name: "Raw Steel", type: "RAW", quantity: 100, avgCost: 50 },
    { name: "Finished Widget", type: "FINISHED", quantity: 20, avgCost: 200 },
  ]);

  console.log("Seed data inserted");
  process.exit();
};

seedData();
