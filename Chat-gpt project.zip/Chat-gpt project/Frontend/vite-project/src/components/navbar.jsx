import React from "react";

export default function Navbar() {
  const logout = () => {
    localStorage.removeItem("token");
    window.location.reload();
  };

  return (
    <nav className="navbar navbar-dark bg-dark px-3">
      <span className="navbar-brand">Accounting System</span>
      <button className="btn btn-sm btn-danger" onClick={logout}>
        Logout
      </button>
    </nav>
  );
}
