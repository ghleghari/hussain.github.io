import React, { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function Inventory() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    apiFetch("/inventory").then(setItems);
  }, []);

  return (
    <>
      <h4>Inventory</h4>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Qty</th>
            <th>Avg Cost</th>
          </tr>
        </thead>
        <tbody>
          {items.map((i) => (
            <tr key={i._id}>
              <td>{i.name}</td>
              <td>{i.type}</td>
              <td>{i.quantity}</td>
              <td>{i.avgCost}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
