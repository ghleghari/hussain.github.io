import React, { useEffect, useState } from "react";
import { apiFetch } from "../api";

export default function Reports() {
  const [entries, setEntries] = useState([]);

  useEffect(() => {
    apiFetch("/reports/trial-balance").then(setEntries);
  }, []);

  return (
    <>
      <h4>Trial Balance</h4>
      <table className="table table-sm table-bordered">
        <thead>
          <tr>
            <th>Date</th>
            <th>Description</th>
            <th>Debit</th>
            <th>Credit</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          {entries.map((e) => (
            <tr key={e._id}>
              <td>{new Date(e.date).toLocaleDateString()}</td>
              <td>{e.description}</td>
              <td>{e.debitAccount}</td>
              <td>{e.creditAccount}</td>
              <td>{e.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
