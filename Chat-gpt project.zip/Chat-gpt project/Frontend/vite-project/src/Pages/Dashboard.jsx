import React, { useState } from "react";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const login = async () => {
    if (username === "admin" && password === "adminSecret900") {
      localStorage.setItem("token", "admin-token");
      window.location.reload();
    } else {
      alert("Invalid credentials");
    }
  };

  return (
    <div className="container mt-5">
      <h3>Admin Login</h3>

      <input
        className="form-control mt-2"
        placeholder="Username"
        onChange={(e) => setUsername(e.target.value)}
      />

      <input
        className="form-control mt-2"
        type="password"
        placeholder="Password"
        onChange={(e) => setPassword(e.target.value)}
      />

      <button className="btn btn-primary mt-3" onClick={login}>
        Login
      </button>
    </div>
  );
}
