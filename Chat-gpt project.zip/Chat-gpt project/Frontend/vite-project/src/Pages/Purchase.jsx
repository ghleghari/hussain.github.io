import React, { useState } from "react";
import { apiFetch } from "../api";

export default function Purchases() {
  const [itemId, setItemId] = useState("");
  const [qty, setQty] = useState("");
  const [rate, setRate] = useState("");

  const submit = async () => {
    await apiFetch("/transactions/purchase", "POST", {
      itemId,
      quantity: Number(qty),
      rate: Number(rate),
    });
    alert("Purchase recorded");
  };

  return (
    <>
      <h4>Purchase</h4>
      <input
        className="form-control mt-1"
        placeholder="Item ID"
        onChange={(e) => setItemId(e.target.value)}
      />
      <input
        className="form-control mt-1"
        placeholder="Quantity"
        onChange={(e) => setQty(e.target.value)}
      />
      <input
        className="form-control mt-1"
        placeholder="Rate"
        onChange={(e) => setRate(e.target.value)}
      />
      <button className="btn btn-success mt-2" onClick={submit}>
        Save
      </button>
    </>
  );
}
