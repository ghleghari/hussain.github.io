import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";

import Login from "./Pages/Login";
import Dashboard from "./Pages/Dashboard";
import Sales from "./pages/Sales";
import Purchases from "./Pages/Purchase";
import Inventory from "./pages/Inventory";
import Reports from "./pages/Report";

function App() {
  const isLoggedIn = !!localStorage.getItem("token");

  return (
    <Router>
      <Routes>
        <Route
          path="/login"
          element={isLoggedIn ? <Navigate to="/dashboard" /> : <Login />}
        />
        <Route
          path="/dashboard"
          element={isLoggedIn ? <Dashboard /> : <Navigate to="/login" />}
        />
        <Route
          path="/sales"
          element={isLoggedIn ? <Sales /> : <Navigate to="/login" />}
        />
        <Route
          path="/purchases"
          element={isLoggedIn ? <Purchases /> : <Navigate to="/login" />}
        />
        <Route
          path="/inventory"
          element={isLoggedIn ? <Inventory /> : <Navigate to="/login" />}
        />
        <Route
          path="/reports"
          element={isLoggedIn ? <Reports /> : <Navigate to="/login" />}
        />
        <Route
          path="*"
          element={<Navigate to={isLoggedIn ? "/dashboard" : "/login"} />}
        />
      </Routes>
    </Router>
  );
}

export default App;
