const API_URL = "http://localhost:5000/api";

export const apiFetch = async (url, method = "GET", body) => {
  const res = await fetch(`${API_URL}${url}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      Authorization: localStorage.getItem("token"),
    },
    body: body ? JSON.stringify(body) : null,
  });

  return res.json();
};
